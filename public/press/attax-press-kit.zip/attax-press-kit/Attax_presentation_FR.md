# Attax — Kit presse

## En une phrase

Attax est le jeu de fitness gratuit qui transforme tes vraies sÃ©ances en duels de boxe quotidiens : ta montre mesure ton effort, ton boxeur frappe.

## En un paragraphe

Sport is now a game. Attax transforme tes vraies sÃ©ances en duels de boxe quotidiens. Ta montre mesure ton effort via Apple SantÃ© ou Health Connect, et tes sÃ©ances et tes pas deviennent des pts. Chaque jour, tu affrontes un nouveau joueur de ta ligue dans un match en 7 rounds : tes 6 jours d'avant, plus aujourd'hui. Ã€ 21h30, le Soir de combat : entrÃ©e des boxeurs, cartes retournÃ©es, et le round final dÃ©cide. Joue une carte chaque matin, gagne ta ligue et passe de Rookie Ã  Legend. Gratuit sur iPhone et Android, sans publicitÃ©.

## Version longue

La plupart des applis fitness s'arrÃªtent au suivi : des chiffres que personne d'autre ne voit, aucun enjeu. Attax donne une raison d'Ãªtre Ã  chaque sÃ©ance. Les joueurs connectent une montre, un bracelet ou une ceinture cardio via Apple SantÃ© (iPhone) ou Health Connect (Android), et leurs vraies sÃ©ances et leurs pas deviennent des pts. C'est l'intensitÃ© qui paie, pas seulement le volume.

Les joueurs rejoignent une ligue de 8 de leur niveau : 7 jours, un nouvel adversaire chaque jour, 1 champion qui repart avec la couronne. Un match se joue en 7 rounds : les 6 jours d'avant, plus aujourd'hui. Chaque jour est un round, gagnÃ© par celui qui a le plus de pts ; chaque round perdu coÃ»te des PV, et celui qui garde le plus de PV gagne. Jamais de match nul. Les rounds passÃ©s se dÃ©voilent un par un de 10h Ã  17h30, le round final se joue en direct dÃ¨s 19h, et Ã  21h30 vient le Soir de combat : entrÃ©e des boxeurs, rounds rejouÃ©s, cartes retournÃ©es, puis le round final dÃ©cide. Chaque matin, 3 cartes sont tirÃ©es, les mÃªmes pour les deux joueurs (Attaque, DÃ©fense, Sabotage ou Ruse) et le choix de l'adversaire reste secret jusqu'Ã  21h30.

Les joueurs peuvent rejoindre des ligues au hasard Ã  leur niveau, des ligues classÃ©es entre amis ou des ligues personnalisÃ©es de 2 Ã  40. Un rang les suit de Rookie Ã  Legend, une saison mondiale rÃ©compense chaque pt d'effort, et leur profil rÃ©unit sÃ©rie, coups dÃ©bloquÃ©s, badges et trophÃ©es. Attax fonctionne avec tous les sports mesurÃ©s par la montre, et chaque ligue se joue Ã  son heure locale. L'app est gratuite, sans publicitÃ©.

## Attax en un coup d'Å“il.

- **Nom** : Attax
- **CatÃ©gorie** : Jeu de fitness compÃ©titif
- **Plateformes** : iPhone (App Store) & Android (Google Play)
- **Prix** : Gratuit Ã  tÃ©lÃ©charger et Ã  jouer, sans publicitÃ©
- **Source d'activitÃ©** : Apple SantÃ© (iPhone) Â· Health Connect (Android)
- **PrÃ©requis** : Une montre, un bracelet ou une ceinture qui mesure la frÃ©quence cardiaque
- **Format** : Ligues de 8 joueurs, 7 jours, un nouvel adversaire chaque jour, matchs en 7 rounds
- **Cartes** : 12 cartes en 4 familles : 3 tirÃ©es chaque matin, 1 Ã  jouer
- **Soir de combat** : Chaque soir Ã  21h30, heure locale de la ligue
- **Progression** : Un rang de Rookie Ã  Legend, une saison mondiale
- **Langues** : FranÃ§ais, anglais
- **CrÃ©ation** : 2026
- **Site** : attax.app
- **RÃ©seaux** : @playattax sur Instagram, TikTok, X et YouTube

## Attax en quatre points.

- **Ton vrai effort** — Ta montre mesure ton effort via Apple SantÃ© ou Health Connect. Tes sÃ©ances et tes pas deviennent des pts. Les saisies Ã  la main ne comptent pas.
- **Un duel par jour** — Un nouvel adversaire de ta ligue chaque jour, un match en 7 rounds. Rounds passÃ©s dÃ©voilÃ©s de 10h Ã  17h30, round final en direct dÃ¨s 19h, Soir de combat Ã  21h30.
- **Les cartes** — 3 cartes tirÃ©es chaque matin, les mÃªmes pour les deux joueurs, une Ã  jouer avant 13h : Quitte ou double, Garde, Freeze, Ghostâ€¦ La bonne carte peut renverser un match serrÃ©.
- **Ligues et rangs** — Des ligues de 8 joueurs sur 7 jours, 1 champion couronnÃ©, puis on rejoue ou on change de ligue. Un rang de Rookie Ã  Legend.

## Quelques rÃ¨gles simples.

**Ã€ faire**

- Ã‰crire Â« Attax Â» avec un A majuscule uniquement.
- Utiliser les logos et captures tels que fournis.
- Mettre un lien vers attax.app et identifier @playattax.
- PrÃ©senter Attax comme un jeu de fitness gratuit sur iPhone et Android.

**Ã€ Ã©viter**

- DÃ©former, recolorer ou recadrer le logo.
- PrÃ©senter Attax comme une app mÃ©dicale ou de diagnostic santÃ©.
- Promettre des rÃ©sultats, des prix ou des rÃ©compenses que l'app ne propose pas.
- Retoucher les captures de faÃ§on Ã  changer ce que montre l'app.

## Parlons-en.

Interviews, dÃ©mos, partenariats ou collaborations crÃ©ateurs : Ã©cris-nous.

media@attax.app

attax.app · #playattax · @playattax
