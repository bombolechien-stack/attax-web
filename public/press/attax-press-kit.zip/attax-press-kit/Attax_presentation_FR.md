# Attax — Kit presse

## En une phrase

Attax est le jeu de fitness gratuit qui transforme tes vraies sÃ©ances en un duel quotidien contre un joueur de ta ligue.

## En un paragraphe

Attax transforme ton activitÃ© rÃ©elle en compÃ©tition. Ta montre mesure ton effort via Apple SantÃ© ou Health Connect, et chaque sÃ©ance, chaque pas devient des points. Chaque jour, tu affrontes un joueur de ta ligue dans un duel dÃ©voilÃ© round aprÃ¨s round, puis tranchÃ© Ã  21h30. Joue une carte stratÃ©gique chaque matin, grimpe au classement et passe de Rookie Ã  Legend. Gratuit sur iPhone et Android.

## Version longue

La plupart des applis fitness s'arrÃªtent au suivi : des chiffres que personne d'autre ne voit, aucun enjeu. Attax donne une raison d'Ãªtre Ã  chaque sÃ©ance. Les joueurs connectent une montre, un bracelet ou une ceinture cardio via Apple SantÃ© (iPhone) ou Health Connect (Android), et leur effort rÃ©el devient des points d'activitÃ© â€” plus ils poussent, plus ils marquent, et leurs pas comptent aussi.

Les joueurs rejoignent une ligue de 8 de leur niveau : 7 jours, 7 duels, un nouvel adversaire chaque jour. Chaque duel compare les 7 derniers jours d'activitÃ©, dÃ©voilÃ©s round aprÃ¨s round dans la journÃ©e, avec un round final en direct dÃ¨s 19h et un verdict Ã  21h30 â€” jouÃ© comme un combat animÃ© jusqu'au KO. Chaque matin, 3 cartes stratÃ©giques sont tirÃ©es : booster sa sÃ©ance, saboter son adversaire ou cacher son score. Ã€ la fin de la semaine : un podium, puis une revanche ou une nouvelle ligue, pendant qu'un rang global suit chaque joueur de Rookie Ã  Legend.

Attax fonctionne avec tous les sports qui font travailler le cÅ“ur â€” course, vÃ©lo, muscu, sports collectifs, danse â€” et chaque ligue se joue Ã  son heure locale. L'app est gratuite, sans publicitÃ©.

## Attax en un coup d'Å“il.

- **Nom** : Attax
- **CatÃ©gorie** : Jeu de fitness compÃ©titif
- **Plateformes** : iPhone (App Store) & Android (Google Play)
- **Prix** : Gratuit Ã  tÃ©lÃ©charger et Ã  jouer, sans publicitÃ©
- **Source d'activitÃ©** : Apple SantÃ© (iPhone) Â· Health Connect (Android)
- **PrÃ©requis** : Une montre, un bracelet ou une ceinture qui mesure la frÃ©quence cardiaque
- **Format** : Ligues de 8 joueurs, 7 duels en 7 jours
- **StratÃ©gie** : 12 cartes â€” 3 tirÃ©es chaque matin, 1 Ã  jouer
- **Rangs** : 5 divisions, 15 paliers â€” de Rookie Ã  Legend
- **Langues** : FranÃ§ais, anglais
- **CrÃ©ation** : 2026
- **Site** : attax.app
- **RÃ©seaux** : @playattax â€” Instagram, TikTok, X, YouTube

## Attax en quatre points.

- **Ton vrai effort** — Ta montre mesure ton effort via Apple SantÃ© ou Health Connect. Chaque sÃ©ance et chaque pas deviennent des points. Aucune saisie manuelle.
- **Un duel par jour** — Un nouvel adversaire de ta ligue chaque jour. Des rounds dÃ©voilÃ©s dÃ¨s 10h, le round final en direct dÃ¨s 19h, le verdict Ã  21h30.
- **Les cartes stratÃ©giques** — 3 cartes tirÃ©es chaque matin, une Ã  jouer avant 13h : Spike, Shield, Ghost, Mirageâ€¦ La bonne carte peut renverser un duel serrÃ©.
- **Ligues et rangs** — Des ligues de 8 joueurs sur 7 jours, un podium, puis une revanche ou une nouvelle ligue. Un rang global de Rookie Ã  Legend.

## Quelques rÃ¨gles simples.

**Ã€ faire**

- Ã‰crire Â« Attax Â» avec un A majuscule uniquement.
- Utiliser les logos et captures tels que fournis.
- Mettre un lien vers attax.app et identifier @playattax.
- PrÃ©senter Attax comme un jeu de fitness gratuit sur iPhone et Android.

**Ã€ Ã©viter**

- DÃ©former, recolorer ou recadrer le logo.
- PrÃ©senter Attax comme une app mÃ©dicale ou de diagnostic santÃ©.
- Promettre des rÃ©sultats, des prix ou des rÃ©compenses que l'app ne propose pas.
- Retoucher les captures de faÃ§on Ã  changer ce que montre l'app.

## Parlons-en.

Interviews, dÃ©mos, partenariats ou collaborations crÃ©ateurs : Ã©cris-nous.

contact@attax.app

attax.app · #playattax · @playattax
