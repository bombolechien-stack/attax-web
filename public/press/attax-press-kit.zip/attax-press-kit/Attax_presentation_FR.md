# Attax — Kit presse

## En une phrase

Chaque jour, un adversaire de ton niveau. Chaque soir à 21h30, le verdict. Dans Attax, ce sont tes vraies séances de sport qui décident du match.

## En un paragraphe

Fini de s'entraîner pour des chiffres que personne ne regarde. Dans Attax, tu affrontes chaque jour un adversaire de ton niveau, et ce sont tes vraies séances qui décident du match : sept rounds, une carte à jouer chaque matin pour tout renverser, et à 21h30 le soir de combat, où le verdict tombe sous tes yeux. Gagne ta ligue, grimpe de Rookie à Legend, défends ta place au classement mondial. Tu peux aussi jouer en club : ta salle, ton équipe ou ta bande d'amis ont leur propre classement, avec un rival chaque jour. Une montre ou un simple capteur cardio suffit. Gratuit sur iPhone et Android, sans publicité.

## Version longue

La plupart des applications de sport comptent. Attax fait jouer. Des chiffres que personne d'autre ne voit n'ont jamais fait lever qui que ce soit du canapé ; un adversaire qui t'attend, si. C'est l'idée d'Attax : transformer le sport que tu fais déjà en un match à gagner, tous les jours.

Le principe est simple. Tes vraies séances et tes pas deviennent des points. Ils sont mesurés par ta montre, via Apple Santé sur iPhone ou Health Connect sur Android, ou par un capteur cardio Bluetooth, ceinture ou brassard, relié directement à l'app. C'est l'intensité qui paie, pas seulement le volume : une séance courte et engagée rapporte plus qu'une longue promenade. Et rien ne se saisit à la main. On ne gagne qu'en bougeant.

Chaque semaine, tu rejoins une ligue de 8 joueurs de ton niveau, pour 7 jours. Chaque jour, tu affrontes un nouvel adversaire dans un match en 7 rounds : tes 6 jours d'avant, plus aujourd'hui. Chaque jour est un round, remporté par celui qui a marqué le plus de points. Un round perdu coûte 1 PV, le round final en coûte 2, et celui qui garde le plus de PV gagne le match. Il n'y a jamais de match nul. Tant que la journée n'est pas finie, rien n'est joué : une séance en fin d'après-midi peut encore tout changer.

Attax ne se gagne pas qu'avec les jambes. Chaque matin, 3 cartes sont tirées parmi 12, les mêmes pour les deux joueurs : Attaque, Défense, Sabotage ou Ruse. Tu en joues une, ton adversaire aussi, et son choix reste secret jusqu'au soir. Doubler la mise sur une journée où tu te sens fort, te protéger un jour de repos, piéger un adversaire trop sûr de lui : la bonne carte renverse un match serré.

Puis vient 21h30, le soir de combat. Les deux boxeurs entrent, les rounds se rejouent un à un, les cartes se retournent, et le round final décide du vainqueur. C'est le rendez-vous de la journée, celui qu'on regarde seul dans son canapé ou à plusieurs, et qui donne envie de remettre ses baskets le lendemain.

Il y a toujours une suite. Le champion de la ligue repart avec la couronne, puis une nouvelle ligue commence. Un rang te suit de Rookie à Legend. Une saison mondiale classe tous les joueurs sur leur effort. Dès ta deuxième ligue, un binôme t'est attribué pour tenir dans la durée. Et ton profil garde tout ce que tu gagnes : trophées, série de jours actifs, coups débloqués.

Attax se joue aussi avec les tiens. Tu peux créer une ligue entre amis, ou une ligue personnalisée de 2 à 40 joueurs. Et avec les clubs, le jeu s'ouvre aux communautés : une salle de sport, un club, un coach, un créateur ou une entreprise crée le sien en une minute. Chaque jour, chaque membre y affronte un rival ; chaque mois, un champion reçoit une coupe au logo du club. Créer et gérer un club est gratuit.

Course, vélo, musculation, natation, sports collectifs, danse : tous les sports comptent. Chaque ligue se joue à son heure locale, l'app existe en 15 langues, et tes données de santé ne sont jamais vendues ni montrées aux autres joueurs. Attax est gratuit sur iPhone et Android, sans publicité.

## Attax en un coup d'œil.

- **Nom** : Attax
- **Catégorie** : Jeu de fitness compétitif
- **Plateformes** : iPhone (App Store) & Android (Google Play)
- **Prix** : Gratuit à télécharger et à jouer, sans publicité
- **Source d'activité** : Apple Santé (iPhone) · Health Connect (Android) · capteur cardio Bluetooth, relié directement à l'app
- **Prérequis** : Une montre connectée, ou un capteur cardio Bluetooth (ceinture, brassard)
- **Format** : Ligues de 8 joueurs, 7 jours, un nouvel adversaire chaque jour, matchs en 7 rounds
- **Cartes** : 12 cartes en 4 familles : 3 tirées chaque matin, 1 à jouer
- **Soir de combat** : Chaque soir à 21h30, heure locale de la ligue
- **Progression** : Un rang de Rookie à Legend, une saison mondiale
- **Clubs** : Pour les salles, clubs de sport, coachs, créateurs et entreprises : un rival par jour, un champion par mois. Gratuit à créer et à gérer
- **Langues** : 15 langues : français, anglais, espagnol, portugais (Brésil), allemand, néerlandais, italien, suédois, finnois, danois, russe, hindi, arabe, japonais et chinois simplifié
- **Création** : 2026
- **Site** : attax.app
- **Réseaux** : @playattax sur Instagram, TikTok, X et YouTube

## Attax en quatre points.

- **Ton vrai effort** — Ta montre (via Apple Santé ou Health Connect) ou ton capteur cardio Bluetooth mesure ton effort. Tes séances et tes pas deviennent des points. Les saisies à la main ne comptent pas.
- **Un duel par jour** — Un nouvel adversaire de ta ligue chaque jour, un match en 7 rounds. Rounds passés joués de 10h à 19h, round final en direct dès 19h, soir de combat à 21h30.
- **Les cartes** — 3 cartes tirées chaque matin, les mêmes pour les deux joueurs, une à jouer avant 13h : Quitte ou double, Garde, Freeze, Ghost… La bonne carte peut renverser un match serré.
- **Ligues et rangs** — Des ligues de 8 joueurs sur 7 jours, 1 champion couronné, puis on rejoue ou on change de ligue. Un rang de Rookie à Legend.

## Quelques règles simples.

**À faire**

- Écrire « Attax » avec un A majuscule uniquement.
- Utiliser les logos et captures tels que fournis.
- Mettre un lien vers attax.app et identifier @playattax.
- Présenter Attax comme un jeu de fitness gratuit sur iPhone et Android.

**À éviter**

- Déformer, recolorer ou recadrer le logo.
- Présenter Attax comme une app médicale ou de diagnostic santé.
- Promettre des résultats, des prix ou des récompenses que l'app ne propose pas.
- Retoucher les captures de façon à changer ce que montre l'app.

## Parlons-en.

Interviews, démos ou articles sur Attax : écris-nous.

media@attax.app

attax.app · #playattax · @playattax
