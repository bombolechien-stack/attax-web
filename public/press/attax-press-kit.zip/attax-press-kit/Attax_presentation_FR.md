# Attax — Kit presse

## En une phrase

Attax est le jeu de fitness gratuit qui transforme tes vraies séances en duels quotidiens : ta montre mesure ton effort, tes adversaires sont de ton niveau.

## En un paragraphe

Le sport devient un jeu. Attax transforme tes vraies séances en duels quotidiens. Ta montre ou ton capteur cardio mesure ton effort, et tes séances et tes pas deviennent des points. Chaque jour, tu affrontes un nouveau joueur de ta ligue dans un match de boxe en 7 rounds : tes 6 jours d'avant, plus aujourd'hui. À 21h30, le Soir de combat : entrée des boxeurs, cartes retournées, et le round final décide. Joue une carte chaque matin, gagne ta ligue et passe de Rookie à Legend. Et avec les clubs, une salle, une équipe ou une communauté se défie chaque jour. Gratuit sur iPhone et Android, sans publicité.

## Version longue

La plupart des applications fitness s'arrêtent au suivi : des chiffres que personne d'autre ne voit, aucun enjeu. Attax donne une raison d'être à chaque séance. Les joueurs connectent une montre (via Apple Santé ou Health Connect) ou un capteur cardio Bluetooth (ceinture, brassard) relié directement à l'app, et leurs vraies séances et leurs pas deviennent des points. C'est l'intensité qui paie, pas seulement le volume.

Les joueurs rejoignent une ligue de 8 de leur niveau : 7 jours, un nouvel adversaire chaque jour, 1 champion qui repart avec la couronne. Un match se joue en 7 rounds : les 6 jours d'avant, plus aujourd'hui. Chaque jour est un round, gagné par celui qui a le plus de points ; un round perdu coûte 1 PV (le round final, 2 PV), et celui qui garde le plus de PV gagne. Jamais de match nul. Les rounds passés se dévoilent un par un de 10h à 19h, le round final se joue en direct dès 19h, et à 21h30 vient le Soir de combat : entrée des boxeurs, rounds rejoués, cartes retournées, puis le round final décide. Chaque matin, 3 cartes sont tirées, les mêmes pour les deux joueurs (Attaque, Défense, Sabotage ou Ruse) et le choix de l'adversaire reste secret jusqu'à 21h30.

Les joueurs peuvent rejoindre des ligues au hasard à leur niveau, des ligues classées entre amis ou des ligues personnalisées de 2 à 40. Un rang les suit de Rookie à Legend, une saison mondiale récompense chaque point d'effort, et leur profil réunit série, coups débloqués, badges et trophées. Attax fonctionne avec tous les sports mesurés par la montre, et chaque ligue se joue à son heure locale.

Les clubs ouvrent le jeu aux communautés : une salle de sport, un club, un coach, un créateur ou une entreprise crée son club en une minute. Chaque jour, chaque membre y affronte un rival ; chaque mois, un champion reçoit une coupe au logo du club. Créer et gérer un club est gratuit.

L'app est gratuite, sans publicité.

## Attax en un coup d'œil.

- **Nom** : Attax
- **Catégorie** : Jeu de fitness compétitif
- **Plateformes** : iPhone (App Store) & Android (Google Play)
- **Prix** : Gratuit à télécharger et à jouer, sans publicité
- **Source d'activité** : Apple Santé (iPhone) · Health Connect (Android) · capteur cardio Bluetooth, relié directement à l'app
- **Prérequis** : Une montre connectée, ou un capteur cardio Bluetooth (ceinture, brassard)
- **Format** : Ligues de 8 joueurs, 7 jours, un nouvel adversaire chaque jour, matchs en 7 rounds
- **Cartes** : 12 cartes en 4 familles : 3 tirées chaque matin, 1 à jouer
- **Soir de combat** : Chaque soir à 21h30, heure locale de la ligue
- **Progression** : Un rang de Rookie à Legend, une saison mondiale
- **Clubs** : Pour les salles, clubs de sport, coachs, créateurs et entreprises : un rival par jour, un champion par mois. Gratuit à créer et à gérer
- **Langues** : 15 langues : français, anglais, espagnol, portugais (Brésil), allemand, néerlandais, italien, suédois, finnois, danois, russe, hindi, arabe, japonais et chinois simplifié
- **Création** : 2026
- **Site** : attax.app
- **Réseaux** : @playattax sur Instagram, TikTok, X et YouTube

## Attax en quatre points.

- **Ton vrai effort** — Ta montre (via Apple Santé ou Health Connect) ou ton capteur cardio Bluetooth mesure ton effort. Tes séances et tes pas deviennent des points. Les saisies à la main ne comptent pas.
- **Un duel par jour** — Un nouvel adversaire de ta ligue chaque jour, un match en 7 rounds. Rounds passés joués de 10h à 19h, round final en direct dès 19h, Soir de combat à 21h30.
- **Les cartes** — 3 cartes tirées chaque matin, les mêmes pour les deux joueurs, une à jouer avant 13h : Quitte ou double, Garde, Freeze, Ghost… La bonne carte peut renverser un match serré.
- **Ligues et rangs** — Des ligues de 8 joueurs sur 7 jours, 1 champion couronné, puis on rejoue ou on change de ligue. Un rang de Rookie à Legend.

## Quelques règles simples.

**À faire**

- Écrire « Attax » avec un A majuscule uniquement.
- Utiliser les logos et captures tels que fournis.
- Mettre un lien vers attax.app et identifier @playattax.
- Présenter Attax comme un jeu de fitness gratuit sur iPhone et Android.

**À éviter**

- Déformer, recolorer ou recadrer le logo.
- Présenter Attax comme une app médicale ou de diagnostic santé.
- Promettre des résultats, des prix ou des récompenses que l'app ne propose pas.
- Retoucher les captures de façon à changer ce que montre l'app.

## Parlons-en.

Interviews, démos ou articles sur Attax : écris-nous.

media@attax.app

attax.app · #playattax · @playattax
