# Attax — Press kit

## In one sentence

Every day, an opponent at your level. Every night at 9:30 PM, the verdict. In Attax, your real workouts decide the match.

## In one paragraph

No more training for numbers nobody looks at. In Attax, you take on an opponent at your level every day, and your real workouts decide the match: seven rounds, a card to play every morning to turn it all around, and at 9:30 PM Fight Night, where the verdict lands right in front of you. Win your league, climb from Rookie to Legend, defend your place in the world ranking. You can also play in a club: your gym, your team or your group of friends get their own ranking, with a rival every day. A watch or a simple heart-rate sensor is all you need. Free on iPhone and Android, with no ads.

## Long version

Most fitness apps count. Attax makes you play. Numbers nobody else sees never got anyone off the sofa; an opponent waiting for you does. That's the idea behind Attax: turning the sport you already do into a match to win, every single day.

The principle is simple. Your real workouts and steps become points. They are measured by your watch, through Apple Health on iPhone or Health Connect on Android, or by a Bluetooth heart-rate sensor, chest strap or armband, linked straight to the app. Intensity pays, not just volume: a short, committed session earns more than a long stroll. And nothing can be entered by hand. The only way to win is to move.

Every week, you join a league of 8 players at your level, for 7 days. Every day, you face a new opponent in a match of 7 rounds: your previous 6 days, plus today. Each day is a round, won by whoever scored the most points. A lost round costs 1 HP, the final round costs 2, and the player with the most HP left wins the match. There is never a draw. As long as the day isn't over, nothing is settled: a late-afternoon session can still change everything.

Attax isn't won with your legs alone. Every morning, 3 cards are drawn out of 12, the same for both players: Attack, Defense, Sabotage or Trick. You play one, so does your opponent, and their pick stays secret until the evening. Double down on a day you feel strong, protect yourself on a rest day, trap an opponent who is too sure of themselves: the right card flips a close match.

Then comes 9:30 PM, Fight Night. The two boxers walk out, the rounds replay one by one, the cards flip, and the final round decides the winner. It's the appointment of the day, the one you watch alone on the sofa or with friends, and the one that makes you lace up again the next morning.

There is always a next step. The league champion leaves with the crown, then a new league begins. A rank follows you from Rookie to Legend. A worldwide season ranks every player on their effort. From your second league, a duo partner is assigned to keep you going. And your profile keeps everything you win: trophies, active-day streak, unlocked moves.

Attax is also played with your own people. You can create a league with friends, or a custom league of 2 to 40 players. And with clubs, the game opens up to communities: a gym, a sports club, a coach, a creator or a company creates its own in one minute. Every day, each member takes on a rival there; every month, a champion gets a cup with the club's logo. Creating and running a club is free.

Running, cycling, lifting, swimming, team sports, dance: every sport counts. Every league plays on its own local time, the app is available in 15 languages, and your health data is never sold nor shown to other players. Attax is free on iPhone and Android, with no ads.

## Attax at a glance.

- **Name**: Attax
- **Category**: Competitive fitness game
- **Platforms**: iPhone (App Store) & Android (Google Play)
- **Price**: Free to download and play, no ads
- **Activity source**: Apple Health (iPhone) · Health Connect (Android) · Bluetooth heart-rate sensor, connected straight to the app
- **Requires**: A smartwatch, or a Bluetooth heart-rate sensor (chest strap, armband)
- **Format**: Leagues of 8 players, 7 days, a new opponent every day, matches in 7 rounds
- **Cards**: 12 cards in 4 families: 3 drawn every morning, 1 to play
- **Fight Night**: Every evening at 9:30 PM, league local time
- **Progression**: A rank from Rookie to Legend, a worldwide season
- **Clubs**: For gyms, sports clubs, coaches, creators and companies: a rival every day, a champion every month. Free to create and to run
- **Languages**: 15 languages: English, French, Spanish, Portuguese (Brazil), German, Dutch, Italian, Swedish, Finnish, Danish, Russian, Hindi, Arabic, Japanese and Chinese (Simplified)
- **Founded**: 2026
- **Website**: attax.app
- **Social**: @playattax on Instagram, TikTok, X and YouTube

## Attax in four points.

- **Your real effort** — Your watch (through Apple Health or Health Connect) or your Bluetooth heart-rate sensor measures your effort. Your workouts and steps become points. Manual entries don't count.
- **A duel every day** — A new opponent from your league every day, a match in 7 rounds. Past rounds played out from 10 AM to 7 PM, the final round live from 7 PM, Fight Night at 9:30 PM.
- **The cards** — 3 cards drawn every morning, the same for both players, one to play before 1 PM: Double or nothing, Guard, Freeze, Ghost… The right card can flip a close match.
- **Leagues and ranks** — Leagues of 8 players over 7 days, 1 champion with the crown, then run it back or start a new league. A rank from Rookie to Legend.

## A few simple rules.

**Please do**

- Write "Attax" with a capital A only.
- Use the logos and screenshots as provided.
- Link to attax.app and tag @playattax.
- Present Attax as a free fitness game for iPhone and Android.

**Please don't**

- Distort, recolor or crop the logo.
- Present Attax as a medical or health-diagnosis app.
- Promise results, prizes or rewards that the app doesn't offer.
- Edit screenshots in a way that changes what the app shows.

## Let's talk.

Interviews, demos or coverage of Attax: write to us.

media@attax.app

attax.app · #playattax · @playattax
