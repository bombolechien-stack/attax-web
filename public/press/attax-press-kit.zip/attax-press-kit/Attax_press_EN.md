# Attax — Press kit

## In one sentence

Attax is the free fitness game that turns your real workouts into daily duels: your watch measures your effort, your opponents are at your level.

## In one paragraph

Sport is now a game. Attax turns your real workouts into daily duels. Your watch or heart-rate sensor measures your effort, and your workouts and steps become points. Every day, you face a new player of your league in a boxing match of 7 rounds: your previous 6 days, plus today. At 9:30 PM, Fight Night: the boxers walk out, the cards flip, and the final round decides. Play a card every morning, win your league, and rise from Rookie to Legend. And with clubs, a gym, a team or a community takes each other on every day. Free on iPhone and Android, with no ads.

## Long version

Most fitness apps stop at tracking: numbers nobody else sees, nothing at stake. Attax gives your workouts a reason to exist. Players connect a watch (through Apple Health or Health Connect) or a Bluetooth heart-rate sensor (chest strap, armband) linked straight to the app, and their real workouts and steps become points. It's intensity that pays, not just volume.

Players join a league of 8 at their level: 7 days, a new opponent every day, 1 champion who leaves with the crown. A match is 7 rounds: the previous 6 days, plus today. Each day is a round, won by the player with the most points; a lost round costs 1 HP (the final round, 2 HP), and the player with the most HP left wins. Never a draw. The past rounds are revealed one by one from 10 AM to 7 PM, the final round is live from 7 PM, and at 9:30 PM comes Fight Night: the boxers walk out, the rounds replay, the cards flip, and the final round decides. Every morning, 3 cards are drawn, the same for both players (Attack, Defense, Sabotage or Trick) and the opponent's pick stays secret until 9:30 PM.

Players can join random leagues at their level, ranked leagues with friends, or custom leagues of 2 to 40. A rank follows them from Rookie to Legend, a worldwide season rewards every point of effort, and their profile collects streaks, unlocked moves, badges and trophies. Attax works with any sport the watch measures, and every league plays on its own local time.

Clubs open the game to communities: a gym, a sports club, a coach, a creator or a company creates its club in one minute. Every day, each member takes on a rival there; every month, a champion gets a cup with the club's logo. Creating and running a club is free.

The app is free, with no ads.

## Attax at a glance.

- **Name**: Attax
- **Category**: Competitive fitness game
- **Platforms**: iPhone (App Store) & Android (Google Play)
- **Price**: Free to download and play, no ads
- **Activity source**: Apple Health (iPhone) · Health Connect (Android) · Bluetooth heart-rate sensor, connected straight to the app
- **Requires**: A smartwatch, or a Bluetooth heart-rate sensor (chest strap, armband)
- **Format**: Leagues of 8 players, 7 days, a new opponent every day, matches in 7 rounds
- **Cards**: 12 cards in 4 families: 3 drawn every morning, 1 to play
- **Fight Night**: Every evening at 9:30 PM, league local time
- **Progression**: A rank from Rookie to Legend, a worldwide season
- **Clubs**: For gyms, sports clubs, coaches, creators and companies: a rival every day, a champion every month. Free to create and to run
- **Languages**: 15 languages: English, French, Spanish, Portuguese (Brazil), German, Dutch, Italian, Swedish, Finnish, Danish, Russian, Hindi, Arabic, Japanese and Chinese (Simplified)
- **Founded**: 2026
- **Website**: attax.app
- **Social**: @playattax on Instagram, TikTok, X and YouTube

## Attax in four points.

- **Your real effort** — Your watch (through Apple Health or Health Connect) or your Bluetooth heart-rate sensor measures your effort. Your workouts and steps become points. Manual entries don't count.
- **A duel every day** — A new opponent from your league every day, a match in 7 rounds. Past rounds played out from 10 AM to 7 PM, the final round live from 7 PM, Fight Night at 9:30 PM.
- **The cards** — 3 cards drawn every morning, the same for both players, one to play before 1 PM: Double or nothing, Guard, Freeze, Ghost… The right card can flip a close match.
- **Leagues and ranks** — Leagues of 8 players over 7 days, 1 champion with the crown, then run it back or start a new league. A rank from Rookie to Legend.

## A few simple rules.

**Please do**

- Write "Attax" with a capital A only.
- Use the logos and screenshots as provided.
- Link to attax.app and tag @playattax.
- Present Attax as a free fitness game for iPhone and Android.

**Please don't**

- Distort, recolor or crop the logo.
- Present Attax as a medical or health-diagnosis app.
- Promise results, prizes or rewards that the app doesn't offer.
- Edit screenshots in a way that changes what the app shows.

## Let's talk.

Interviews, demos or coverage of Attax: write to us.

media@attax.app

attax.app · #playattax · @playattax
