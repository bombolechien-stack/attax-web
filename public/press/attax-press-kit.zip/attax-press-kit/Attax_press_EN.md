# Attax — Press kit

## In one sentence

Attax is the free fitness game that turns your real workouts into a daily duel against a player of your league.

## In one paragraph

Attax turns your real activity into competition. Your watch measures your effort through Apple Health or Health Connect, and every workout and every step becomes points. Every day, you face a player of your league in a duel revealed round by round, then settled at 9:30 PM. Play a strategy card every morning, climb the standings, and rise from Rookie to Legend. Free on iPhone and Android.

## Long version

Most fitness apps stop at tracking: numbers nobody else sees, nothing at stake. Attax gives your workouts a reason to exist. Players connect a watch, band or chest strap through Apple Health (iPhone) or Health Connect (Android), and their real effort becomes activity points â€” the harder they push, the more they score, and their steps count too.

Players join a league of 8 at their level: 7 days, 7 duels, a new opponent every day. Each duel compares the last 7 days of activity, revealed round by round through the day, with the final round live from 7 PM and the verdict at 9:30 PM â€” played out as an animated fight to the KO. Every morning, 3 strategy cards are drawn: boost your session, sabotage your opponent, or hide your score. At the end of the week: a podium, then a rematch or a new league, while a global rank follows each player from Rookie to Legend.

Attax works with any sport that gets the heart working â€” running, cycling, gym, team sports, dance â€” and every league plays on its own local time. The app is free, with no ads.

## Attax at a glance.

- **Name**: Attax
- **Category**: Competitive fitness game
- **Platforms**: iPhone (App Store) & Android (Google Play)
- **Price**: Free to download and play, no ads
- **Activity source**: Apple Health (iPhone) Â· Health Connect (Android)
- **Requires**: A watch, band or chest strap that measures heart rate
- **Format**: Leagues of 8 players, 7 duels in 7 days
- **Strategy**: 12 cards â€” 3 drawn every morning, 1 to play
- **Ranks**: 5 divisions, 15 tiers â€” from Rookie to Legend
- **Languages**: English, French
- **Founded**: 2026
- **Website**: attax.app
- **Social**: @playattax â€” Instagram, TikTok, X, YouTube

## Attax in four points.

- **Your real effort** — Your watch measures your effort through Apple Health or Health Connect. Every workout and every step becomes points. No manual entry.
- **A duel every day** — A new opponent from your league every day. Rounds revealed from 10 AM, the final round live from 7 PM, the verdict at 9:30 PM.
- **Strategy cards** — 3 cards drawn every morning, one to play before 1 PM: Spike, Shield, Ghost, Mirageâ€¦ The right card can flip a close duel.
- **Leagues and ranks** — Leagues of 8 players over 7 days, a podium, then a rematch or a new league. A global rank from Rookie to Legend.

## A few simple rules.

**Please do**

- Write "Attax" with a capital A only.
- Use the logos and screenshots as provided.
- Link to attax.app and tag @playattax.
- Present Attax as a free fitness game for iPhone and Android.

**Please don't**

- Distort, recolor or crop the logo.
- Present Attax as a medical or health-diagnosis app.
- Promise results, prizes or rewards that the app doesn't offer.
- Edit screenshots in a way that changes what the app shows.

## Let's talk.

Interviews, demos, partnerships or creator collaborations: write to us.

contact@attax.app

attax.app · #playattax · @playattax
